package com.amiri.pelvicfloor;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.graphics.drawable.GradientDrawable;import android.graphics.drawable.AnimationDrawable;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity{
    LinearLayout root; android.content.SharedPreferences prefs; int day; final String[] names={"تنفس و رهاسازی","کگل آهسته","کگل سریع","پل باسن","Bird-Dog","نشستن و بلندشدن"}; final int[] anims={R.drawable.breath_anim,R.drawable.slow_anim,R.drawable.quick_anim,R.drawable.bridge_anim,R.drawable.bird_anim,R.drawable.sit_anim};
    final String[] desc={
      "یک دقیقه آرام نفس بکشید. دم را بدون زور انجام دهید و هنگام بازدم بدن را شل نگه دارید. هدف این بخش آماده‌سازی و رهاسازی است.",
      "در وضعیت راحت، عضلات کف لگن را به‌آرامی منقبض کنید، بدون حبس نفس یا سفت‌کردن شکم، باسن و ران‌ها. سپس کاملاً رها کنید.",
      "انقباض‌های کوتاه و کنترل‌شده انجام دهید و بعد هر بار کامل رها کنید. سرعت مهم نیست؛ کنترل و رهاسازی کامل مهم‌تر است.",
      "به پشت دراز بکشید، زانوها خم و کف پاها روی زمین. لگن را آرام بالا بیاورید، مکث کوتاه، سپس کنترل‌شده پایین بیاورید. کمر را بیش از حد گود نکنید.",
      "چهاردست‌وپا قرار بگیرید. شکم را آرام نگه دارید و دست و پای مخالف را تا حد راحتی دراز کنید، سپس برگردانید و سمت دیگر را انجام دهید.",
      "روی صندلی محکم بنشینید. با کنترل بلند شوید و دوباره آرام بنشینید. زانوها در مسیر پاها بمانند و حرکت بدون عجله باشد."
    };
    final String[] tips={"اگر سرگیجه یا درد داشتی، متوقف شو.","نفس را حبس نکن و فشار اضافه وارد نکن.","بین انقباض‌ها رهاسازی کامل داشته باش.","حرکت باید آرام و بدون درد باشد.","تعادل مهم‌تر از دامنه حرکت است.","صندلی ثابت باشد و حرکت کنترل‌شده انجام شود."};
    @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("progress",0);day=prefs.getInt("day",0);showHome();}
    TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(Color.rgb(35,42,54));t.setPadding(20,14,20,14);return t;}
    GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(r);return g;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(15);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setBackground(bg(Color.rgb(22,145,135),28));b.setPadding(10,8,10,8);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,58);p.setMargins(0,8,0,8);b.setLayoutParams(p);return b;}
    ScrollView page(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(20,18,20,24);root.setBackgroundColor(Color.rgb(247,249,252));ScrollView s=new ScrollView(this);s.addView(root);setContentView(s);return s;}
    void header(String title){TextView h=tv(title,25);h.setTypeface(null,1);h.setTextColor(Color.rgb(22,120,115));root.addView(h);}
    void showHome(){page();header("تمرین کف لگن");TextView who=tv("تمرین‌کننده: آقای امیری",18);who.setTypeface(null,1);who.setBackground(bg(Color.WHITE,28));root.addView(who);root.addView(tv("برنامه ۴ هفته‌ای • ۲۸ روز\nهدف: تمرین منظم، کنترل‌شده و بدون درد",17));
      TextView prog=tv("پیشرفت: "+day+" از ۲۸ روز  •  "+(day*100/28)+"٪",18);prog.setTypeface(null,1);prog.setBackground(bg(Color.rgb(231,241,242),24));root.addView(prog);
      Button start=btn(day>=28?"برنامه کامل شد 🎉":"شروع تمرین امروز — روز "+(day+1));start.setEnabled(day<28);start.setOnClickListener(v->showWorkout());root.addView(start);
      Button learn=btn("📚 آموزش حرکات با تصویر متحرک");learn.setOnClickListener(v->showLearn());root.addView(learn);
      Button progress=btn("📈 پیشرفت ۲۸ روزه");progress.setOnClickListener(v->showProgress());root.addView(progress);
      root.addView(tv("نکته ایمنی\nتمرین باید راحت و کنترل‌شده باشد. اگر درد، سرگیجه یا ناراحتی غیرعادی ایجاد شد، تمرین را متوقف کن و با پزشک یا فیزیوتراپیستت مشورت کن.",15));
    }
    int week(){return Math.min(4,day/7+1);} int dur(int i){int w=week();int[][] d={{60,60,60,90,90,60},{60,75,60,120,120,75},{60,90,75,120,120,90},{60,120,90,150,150,90}};return d[w-1][i];}
    void showWorkout(){page();header("روز "+(day+1)+" از ۲۸  •  هفته "+week());root.addView(tv("ترتیب پیشنهادی: از حرکت ۱ تا ۶ پیش برو. هر کارت را باز کن، تصویر متحرک را ببین و سپس تایمر را اجرا کن.",15));
      for(int i=0;i<6;i++){final int idx=i;LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(14,10,14,10);card.setBackground(bg(Color.WHITE,26));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,8,0,8);card.setLayoutParams(cp);
        TextView title=tv((i+1)+". "+names[i]+"   •   "+dur(i)+" ثانیه",18);title.setTypeface(null,1);card.addView(title);
        ImageView im=new ImageView(this);im.setImageResource(anims[i]);im.setScaleType(ImageView.ScaleType.CENTER_CROP);im.setAdjustViewBounds(true);card.addView(im,new LinearLayout.LayoutParams(-1,270));AnimationDrawable ad=(AnimationDrawable)im.getDrawable();ad.start();
        card.addView(tv(desc[i],15));TextView tip=tv("نکته: "+tips[i],14);tip.setTextColor(Color.rgb(80,92,105));card.addView(tip);
        Button timer=btn("⏱ شروع تایمر "+dur(i)+" ثانیه");timer.setOnClickListener(v->runTimer(idx,dur(idx),timer));card.addView(timer);root.addView(card);
      }
      Button done=btn("✅ تکمیل تمرین امروز");done.setOnClickListener(v->{if(day<28){day++;prefs.edit().putInt("day",day).apply();Toast.makeText(this,"روز امروز ثبت شد ✔",Toast.LENGTH_SHORT).show();showHome();}});root.addView(done);
      Button back=btn("بازگشت");back.setOnClickListener(v->showHome());root.addView(back);
    }
    void runTimer(int idx,int seconds,Button b){b.setEnabled(false);new CountDownTimer(seconds*1000L,1000){public void onTick(long m){b.setText("⏱ "+((m+999)/1000)+" ثانیه باقی مانده");}public void onFinish(){b.setText("✔ تمام شد — دوباره اجرا کن");b.setEnabled(true);Toast.makeText(MainActivity.this,names[idx]+" تمام شد",Toast.LENGTH_SHORT).show();}}.start();}
    void showLearn(){page();header("آموزش کامل حرکات");root.addView(tv("تصویرها داخل خود برنامه هستند و برای فهم بهتر حرکت، به‌صورت متحرک نمایش داده می‌شوند. اول توضیح را بخوان، بعد حرکت را آرام اجرا کن.",15));for(int i=0;i<6;i++){final int idx=i;LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(14,10,14,10);c.setBackground(bg(Color.WHITE,26));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,8,0,8);c.setLayoutParams(p);c.addView(tv((i+1)+". "+names[i],20));ImageView im=new ImageView(this);im.setImageResource(anims[i]);im.setAdjustViewBounds(true);im.setScaleType(ImageView.ScaleType.CENTER_CROP);c.addView(im,new LinearLayout.LayoutParams(-1,290));AnimationDrawable ad=(AnimationDrawable)im.getDrawable();ad.start();c.addView(tv(desc[i],15));c.addView(tv("نکته مهم: "+tips[i],14));root.addView(c);}Button back=btn("بازگشت به صفحه اصلی");back.setOnClickListener(v->showHome());root.addView(back);}
    void showProgress(){page();header("پیشرفت ۲۸ روزه");root.addView(tv("تعداد روزهای ثبت‌شده: "+day+" / 28",20));for(int w=1;w<=4;w++){int done=Math.max(0,Math.min(7,day-(w-1)*7));LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(14,10,14,10);c.setBackground(bg(Color.WHITE,24));c.addView(tv("هفته "+w+"   •   "+done+" / 7 روز",18));TextView days=tv(""+((done>=1?"●":"○"))+"  "+((done>=2?"●":"○"))+"  "+((done>=3?"●":"○"))+"  "+((done>=4?"●":"○"))+"  "+((done>=5?"●":"○"))+"  "+((done>=6?"●":"○"))+"  "+((done>=7?"●":"○")),20);days.setTextColor(Color.rgb(22,145,135));c.addView(days);root.addView(c,new LinearLayout.LayoutParams(-1,95));}
      Button reset=btn("↻ بازنشانی پیشرفت");reset.setOnClickListener(v->{new AlertDialog.Builder(this).setTitle("بازنشانی؟").setMessage("تمام روزهای ثبت‌شده پاک می‌شود.").setNegativeButton("لغو",null).setPositiveButton("بازنشانی",(d,w)->{day=0;prefs.edit().putInt("day",0).apply();showProgress();}).show();});root.addView(reset);Button back=btn("بازگشت");back.setOnClickListener(v->showHome());root.addView(back);
    }
}
