package com.amiri.pelvicfloor;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.AnimationDrawable;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root;
    android.content.SharedPreferences prefs;
    int day;

    final String[] names = {"تنفس و رهاسازی", "کگل آهسته", "کگل سریع", "پل باسن", "Bird-Dog", "نشستن و بلندشدن"};
    final int[] anims = {R.drawable.exercise1_anim, R.drawable.exercise2_anim, R.drawable.exercise3_anim,
            R.drawable.exercise4_anim, R.drawable.exercise5_anim, R.drawable.exercise6_anim};
    final int[] heroes = {R.drawable.exercise1_hero, R.drawable.exercise2_hero, R.drawable.exercise3_hero,
            R.drawable.exercise4_hero, R.drawable.exercise5_hero, R.drawable.exercise6_hero};

    final String[] desc = {
            "یک دقیقه آرام نفس بکشید. دم را بدون زور انجام دهید و هنگام بازدم بدن را شل نگه دارید. هدف این بخش آماده‌سازی و رهاسازی است.",
            "در وضعیت راحت، عضلات کف لگن را به‌آرامی منقبض کنید، بدون حبس نفس یا سفت‌کردن شکم، باسن و ران‌ها. سپس کاملاً رها کنید.",
            "انقباض‌های کوتاه و کنترل‌شده انجام دهید و بعد هر بار کامل رها کنید. سرعت مهم نیست؛ کنترل و رهاسازی کامل مهم‌تر است.",
            "به پشت دراز بکشید، زانوها خم و کف پاها روی زمین. لگن را آرام بالا بیاورید، مکث کوتاه، سپس کنترل‌شده پایین بیاورید.",
            "چهاردست‌وپا قرار بگیرید. دست و پای مخالف را تا حد راحتی دراز کنید، سپس برگردانید و سمت دیگر را انجام دهید. تعادل و کنترل مهم است.",
            "روی صندلی محکم بنشینید. با کنترل بلند شوید و دوباره آرام بنشینید. زانوها در مسیر پاها بمانند و حرکت بدون عجله باشد."
    };
    final String[] tips = {
            "نفس را آرام نگه دار و بدن را رها کن.",
            "نفس را حبس نکن و فشار اضافه وارد نکن.",
            "بین انقباض‌ها رهاسازی کامل داشته باش.",
            "حرکت باید آرام و بدون درد باشد.",
            "تعادل مهم‌تر از دامنه حرکت است.",
            "صندلی ثابت باشد و حرکت کنترل‌شده انجام شود."
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("progress", 0);
        day = prefs.getInt("day", 0);
        showHome();
    }

    TextView tv(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(Color.WHITE);
        t.setPadding(18, 12, 18, 12);
        return t;
    }

    GradientDrawable bg(int color, float r) {
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(r); return g;
    }

    GradientDrawable strokeBg(int fill, int stroke, float r) {
        GradientDrawable g = new GradientDrawable(); g.setColor(fill); g.setCornerRadius(r); g.setStroke(2, stroke); return g;
    }

    Button btn(String s) {
        Button b = new Button(this);
        b.setText(s); b.setTextSize(15); b.setAllCaps(false); b.setTextColor(Color.WHITE);
        b.setBackground(strokeBg(Color.rgb(5, 35, 61), Color.rgb(0, 188, 255), 32));
        b.setPadding(10, 6, 10, 6);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, 58);
        p.setMargins(0, 8, 0, 8); b.setLayoutParams(p); return b;
    }

    ScrollView page() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(14, 14, 14, 24); root.setBackgroundColor(Color.rgb(2, 12, 25));
        ScrollView s = new ScrollView(this); s.addView(root); setContentView(s); return s;
    }

    void header(String title) {
        TextView h = tv(title, 25); h.setTypeface(null, 1); h.setTextColor(Color.rgb(0, 220, 255));
        h.setGravity(Gravity.CENTER); root.addView(h);
    }

    TextView section(String title) {
        TextView t = tv(title, 17); t.setTypeface(null, 1); t.setTextColor(Color.rgb(0, 230, 200));
        t.setBackground(strokeBg(Color.rgb(4, 28, 48), Color.rgb(0, 180, 220), 22));
        return t;
    }

    void showHome() {
        page(); header("تمرین کف لگن");
        TextView who = tv("تمرین‌کننده: آقای امیری", 17); who.setTypeface(null, 1);
        who.setGravity(Gravity.CENTER); who.setBackground(strokeBg(Color.rgb(4, 28, 48), Color.rgb(0, 188, 255), 24)); root.addView(who);

        ImageView hero = new ImageView(this); hero.setImageResource(R.drawable.exercise1_hero); hero.setScaleType(ImageView.ScaleType.CENTER_CROP);
        hero.setAdjustViewBounds(true); root.addView(hero, new LinearLayout.LayoutParams(-1, 250));

        TextView intro = tv("تمرین‌های ساده و کنترل‌شده برای تقویت و هماهنگی عضلات کف لگن\nبرنامه ۴ هفته‌ای • ۲۸ روز", 16);
        intro.setGravity(Gravity.CENTER); root.addView(intro);

        TextView prog = tv("پیشرفت امروز: " + day + " از ۲۸ روز   •   " + (day * 100 / 28) + "٪", 17);
        prog.setGravity(Gravity.CENTER); prog.setBackground(strokeBg(Color.rgb(3, 30, 48), Color.rgb(0, 220, 200), 24)); root.addView(prog);

        Button start = btn(day >= 28 ? "برنامه کامل شد" : "شروع تمرین امروز — روز " + (day + 1));
        start.setOnClickListener(v -> showWorkout()); root.addView(start);
        Button learn = btn("آموزش حرکات با تصویر متحرک"); learn.setOnClickListener(v -> showLearn()); root.addView(learn);
        Button progress = btn("پیشرفت ۲۸ روزه"); progress.setOnClickListener(v -> showProgress()); root.addView(progress);

        TextView safe = tv("نکته ایمنی\nتمرین باید راحت و کنترل‌شده باشد. اگر درد، سرگیجه یا ناراحتی غیرعادی ایجاد شد، تمرین را متوقف کن و با پزشک یا فیزیوتراپیستت مشورت کن.", 14);
        safe.setBackground(bg(Color.rgb(5, 24, 40), 22)); root.addView(safe);
    }

    int week() { return Math.min(4, day / 7 + 1); }
    int dur(int i) {
        int w = week(); int[][] d = {{60,60,60,90,90,60},{60,75,60,120,120,75},{60,90,75,120,120,90},{60,120,90,150,150,90}};
        return d[w-1][i];
    }

    ImageView animatedImage(int idx, int height) {
        ImageView im = new ImageView(this); im.setImageResource(anims[idx]); im.setScaleType(ImageView.ScaleType.CENTER_CROP);
        im.setAdjustViewBounds(true); im.setBackground(strokeBg(Color.rgb(2,18,32), Color.rgb(0,170,240), 24));
        AnimationDrawable ad = (AnimationDrawable) im.getDrawable(); ad.start();
        return im;
    }

    void addExerciseCard(int i, boolean timer) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(10, 10, 10, 10);
        card.setBackground(strokeBg(Color.rgb(4, 23, 39), Color.rgb(0, 150, 210), 28));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.setMargins(0, 8, 0, 8); card.setLayoutParams(cp);

        TextView title = tv((i+1) + ". " + names[i] + "   •   " + dur(i) + " ثانیه", 18); title.setTypeface(null, 1); title.setTextColor(Color.rgb(0, 220, 255)); card.addView(title);
        ImageView hero = new ImageView(this); hero.setImageResource(heroes[i]); hero.setScaleType(ImageView.ScaleType.CENTER_CROP); hero.setAdjustViewBounds(true);
        card.addView(hero, new LinearLayout.LayoutParams(-1, 210));
        ImageView motion = animatedImage(i, 110); card.addView(motion, new LinearLayout.LayoutParams(-1, 120));
        card.addView(section("نحوه انجام حرکت")); card.addView(tv(desc[i], 14));
        TextView tip = tv("نکته مهم: " + tips[i], 14); tip.setTextColor(Color.rgb(170, 240, 235)); tip.setBackground(bg(Color.rgb(3, 38, 43), 18)); card.addView(tip);
        if (timer) {
            Button timerBtn = btn("شروع تایمر " + dur(i) + " ثانیه"); final int idx=i; timerBtn.setOnClickListener(v -> runTimer(idx, dur(idx), timerBtn)); card.addView(timerBtn);
        }
        root.addView(card);
    }

    void showWorkout() {
        page(); header("روز " + (day+1) + " از ۲۸  •  هفته " + week());
        root.addView(tv("از حرکت ۱ تا ۶ پیش برو. تصویر بزرگ، سپس نوار تصویر متحرک را ببین و حرکت را آرام اجرا کن.", 14));
        for (int i=0;i<6;i++) addExerciseCard(i, true);
        Button done = btn("تکمیل تمرین امروز");
        done.setOnClickListener(v -> { if(day<28){ day++; prefs.edit().putInt("day",day).apply(); Toast.makeText(this,"تمرین امروز ثبت شد",Toast.LENGTH_SHORT).show(); showHome(); }}); root.addView(done);
        Button back = btn("بازگشت"); back.setOnClickListener(v -> showHome()); root.addView(back);
    }

    void runTimer(int idx, int seconds, Button b) {
        b.setEnabled(false);
        new CountDownTimer(seconds*1000L,1000) {
            public void onTick(long m){ b.setText(((m+999)/1000)+" ثانیه باقی مانده"); }
            public void onFinish(){ b.setText("تمام شد — دوباره اجرا کن"); b.setEnabled(true); Toast.makeText(MainActivity.this,names[idx]+" تمام شد",Toast.LENGTH_SHORT).show(); }
        }.start();
    }

    void showLearn() {
        page(); header("آموزش حرکات"); root.addView(tv("برای هر حرکت یک تصویر باکیفیت و یک نوار متحرک آموزشی داخل خود برنامه قرار دارد.",14));
        for(int i=0;i<6;i++) addExerciseCard(i, false);
        Button back=btn("بازگشت به صفحه اصلی"); back.setOnClickListener(v->showHome()); root.addView(back);
    }

    void showProgress() {
        page(); header("پیشرفت ۲۸ روزه"); root.addView(tv("تعداد روزهای ثبت‌شده: "+day+" / 28",20));
        for(int w=1;w<=4;w++){
            int done=Math.max(0,Math.min(7,day-(w-1)*7)); LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(14,10,14,10); c.setBackground(strokeBg(Color.rgb(4,23,39),Color.rgb(0,150,210),24));
            c.addView(tv("هفته "+w+"   •   "+done+" / 7 روز",18)); TextView days=tv(""+((done>=1?"●":"○"))+"  "+((done>=2?"●":"○"))+"  "+((done>=3?"●":"○"))+"  "+((done>=4?"●":"○"))+"  "+((done>=5?"●":"○"))+"  "+((done>=6?"●":"○"))+"  "+((done>=7?"●":"○")),20); days.setTextColor(Color.rgb(0,220,200)); c.addView(days); root.addView(c,new LinearLayout.LayoutParams(-1,95));
        }
        Button reset=btn("بازنشانی پیشرفت"); reset.setOnClickListener(v->{new AlertDialog.Builder(this).setTitle("بازنشانی؟").setMessage("تمام روزهای ثبت‌شده پاک می‌شود.").setNegativeButton("لغو",null).setPositiveButton("بازنشانی",(d,w)->{day=0;prefs.edit().putInt("day",0).apply();showProgress();}).show();}); root.addView(reset);
        Button back=btn("بازگشت"); back.setOnClickListener(v->showHome()); root.addView(back);
    }
}
